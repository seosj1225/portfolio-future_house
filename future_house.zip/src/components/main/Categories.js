import React, { useState } from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";
// import item1 from "/images/164333421927911367.png";
// import item2 from "/images/162823225115177697.png";
// import item3 from "/images/162823225665741013.png";
// import item4 from "/images/162823226017937426.png";
// import item5 from "/images/162823226903946200.png";
// import item6 from "/images/162823227719846773.png";
// import item7 from "/images/162823228178967968.png";
// import item8 from "/images/163609843911228804.png";
// import item9 from "/images/164333398177552131.png";
// import item10 from "/images/163575474448469686.png";
// import item11 from "/images/162823230480918647.png";
// import item12 from "/images/162823230908544036.png";
// import item13 from "/images/162823231401891024.png";
// import item14 from "/images/162823242317048198.png";
// import item15 from "/images/162823231949249287.png";
// import item16 from "/images/164148743817769527.png";
import { MdArrowBackIosNew, MdArrowForwardIos } from "react-icons/md";

const Categories = () => {
  const [categoryGroup, setCategoryGroup] = useState(1);

  // prev 버튼 클릭시 이전페이지 보여주기
  const prevGroup = () => {
    let num;
    if (categoryGroup === 1) {
      num = 3;
    } else {
      num = categoryGroup - 1;
    }
    setCategoryGroup(num);
  };

  // next 버튼 클릭시 다음페이지 보여주기
  const nextGroup = () => {
    let num;
    if (categoryGroup === 3) {
      num = 1;
    } else {
      num = categoryGroup + 1;
    }
    setCategoryGroup(num);
  };
  return (
    <Wrapper>
      <section className="row1">
        <header>
          <h2>카테고리별 상품 찾기</h2>
        </header>
        <section>
          <div>
            <ul>
              {categoryGroup === 1 && (
                <li>
                  <Link to="#">
                    <img src="/images/164333421927911367.png" />
                    <p>가구</p>
                  </Link>
                </li>
              )}
              {categoryGroup === 1 && (
                <li>
                  <Link to="#">
                    <img src="/images/162823225115177697.png" />
                    <p>패트릭</p>
                  </Link>
                </li>
              )}
              {categoryGroup === 1 && (
                <li>
                  <Link to="#">
                    <img src="/images/162823225665741013.png" />
                    <p>조명</p>
                  </Link>
                </li>
              )}
              {categoryGroup === 1 && (
                <li>
                  <Link to="#">
                    <img src="/images/162823226017937426.png" />
                    <p>가전</p>
                  </Link>
                </li>
              )}
              {categoryGroup === 1 && (
                <li>
                  <Link to="#">
                    <img src="/images/162823226903946200.png" />
                    <p>주방용품</p>
                  </Link>
                </li>
              )}
              {(categoryGroup === 1 || categoryGroup === 2) && (
                <li>
                  <Link to="#">
                    <img src="/images/162823227719846773.png" />
                    <p>데코/식물</p>
                  </Link>
                </li>
              )}
              <li>
                <Link to="#">
                  <img src="/images/162823228178967968.png" />
                  <p>수납/정리</p>
                </Link>
              </li>
              <li>
                <Link to="#">
                  <img src="/images/163609843911228804.png" />
                  <p>생활용품</p>
                </Link>
              </li>
              <li>
                <Link to="#">
                  <img src="/images/164333398177552131.png" />
                  <p>서랍/수납장</p>
                </Link>
              </li>
              <li>
                <Link to="#">
                  <img src="/images/163575474448469686.png" />
                  <p>생필품</p>
                </Link>
              </li>
              {(categoryGroup === 2 || categoryGroup === 3) && (
                <li>
                  <Link to="#">
                    <img src="/images/162823230480918647.png" />
                    <p>공구/DIY</p>
                  </Link>
                </li>
              )}
              {(categoryGroup === 2 || categoryGroup === 3) && (
                <li>
                  <Link to="#">
                    <img src="/images/162823230908544036.png" />
                    <p>인테리어시공</p>
                  </Link>
                </li>
              )}
              {(categoryGroup === 2 || categoryGroup === 3) && (
                <li>
                  <Link to="#">
                    <img src="/images/162823231401891024.png" />
                    <p>반려동물</p>
                  </Link>
                </li>
              )}
              {(categoryGroup === 2 || categoryGroup === 3) && (
                <li>
                  <Link to="#">
                    <img src="/images/162823242317048198.png" />
                    <p>캠핑용품</p>
                  </Link>
                </li>
              )}
              {(categoryGroup === 2 || categoryGroup === 3) && (
                <li>
                  <Link to="#">
                    <img src="/images/162823231949249287.png" />
                    <p>실내운동</p>
                  </Link>
                </li>
              )}
              {categoryGroup === 3 && (
                <li>
                  <Link to="#">
                    <img src="/images/164148743817769527.png" />
                    <p>렌탈</p>
                  </Link>
                </li>
              )}
            </ul>
          </div>
          <div className="categoryListPrev" onClick={prevGroup}>
            <button>
              <MdArrowBackIosNew />
            </button>
          </div>
          <div className="categoryListNext" onClick={nextGroup}>
            <button>
              <MdArrowForwardIos />
            </button>
          </div>
        </section>
      </section>
    </Wrapper>
  );
};
const Wrapper = styled.div`
  @font-face {
    font-family: "EliceDigitalBaeum-Bd";
    src: url("https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_elice@1.0/EliceDigitalBaeum-Bd.woff2")
      format("woff2");
    font-weight: normal;
    font-style: normal;
  }

  font-family: "EliceDigitalBaeum-Bd";
  section.row1 {
    padding-top: 30px;
    width: 1160px;
    margin: 0 auto;

    header {
      h2 {
        font-size: 20px;
        padding: 0 0 0 10px;
      }
    }
    section {
      position: relative;
      div {
        ul {
          display: flex;
          margin: 0 10px;
          li {
            margin: 20px 0 0;
            min-width: 10%;
            a {
              display: block;
              text-align: center;
              color: #424242;
              img {
                width: 80px;
                margin-bottom: 20px;
              }
            }
          }
        }
      }
      .categoryListPrev,
      .categoryListNext {
        height: 100%;
        width: 64px;
        button {
          cursor: pointer;
          margin: 0 10px;
          position: relative;
          top: 50%;
          border: none;
          width: 32px;
          height: 32px;
          line-height: 16px;
          background-color: rgba(189, 189, 189, 0.8);
          border-radius: 50%;
          font-size: 20px;
          color: #fff;
        }
      }
      .categoryListPrev {
        position: absolute;
        top: 0;
        left: 0;
        background-image: linear-gradient(
          270deg,
          hsla(0, 0%, 100%, 0.01),
          #fff
        );
      }
      .categoryListNext {
        position: absolute;
        top: 0;
        right: 0;
        background-image: linear-gradient(90deg, hsla(0, 0%, 100%, 0.01), #fff);
        button {
          position: absolute;
          right: 0;
        }
      }
    }
  }
`;
export default Categories;

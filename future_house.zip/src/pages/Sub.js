import React from "react";
import Header from "../components/common/header/Header";

const Sub = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default Sub;
